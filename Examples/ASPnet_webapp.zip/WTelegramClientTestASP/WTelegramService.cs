﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;
using TL;

namespace WTelegramClientTestASP
{
	public class WTelegramService : BackgroundService
	{
		public readonly WTelegram.Client Client;
		public User User { get; private set; }
		public Task<string> ConfigNeeded() => _configNeeded.Task;

		private readonly IConfiguration _config;
		private TaskCompletionSource<string> _configNeeded = new();
		private readonly ManualResetEventSlim _configRequest = new();
		private string _configValue;

		public WTelegramService(IConfiguration config, ILogger<WTelegramService> logger)
		{
			_config = config;
			WTelegram.Helpers.Log = (lvl, msg) => logger.Log((LogLevel)lvl, msg);
			Client = new WTelegram.Client(Config);
		}

		private string Config(string what)
		{
			switch (what)
			{
				case "verification_code":
				case "password":
					_configNeeded.SetResult(what);
					_configRequest.Wait();
					_configRequest.Reset();
					return _configValue;
				default:
					return _config[what]; // use the ASP.NET configuration (see launchSettings.json)
			}
		}

		public void ReplyConfig(string value)
		{
			_configValue = value;
			_configNeeded = new();
			_configRequest.Set();
		}

		protected override async Task ExecuteAsync(CancellationToken stoppingToken)
		{
			try
			{
				User = await Client.LoginUserIfNeeded();
			}
			catch (Exception ex)
			{
				_configNeeded.SetException(ex);
				throw;
			}
			_configNeeded.SetResult(null); // login complete
		}
	}
}
